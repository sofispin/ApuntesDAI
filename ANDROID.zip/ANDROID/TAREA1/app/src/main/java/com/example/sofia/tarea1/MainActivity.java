package com.example.sofia.tarea1;

import android.app.Activity;
import android.inputmethodservice.ExtractEditText;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    Button boton1;
    Button boton2;
    Button boton3;
    Button boton4;
    Button botonSuma;
    Button botonResta;
    Button botonMult;
    Button botonDiv;

    RelativeLayout pantalla1;
    RelativeLayout pantalla2;
    RelativeLayout pantalla3;
    RelativeLayout pantalla4;

    EditText editText1;
    EditText editText2;
    EditText editText3;
    EditText editText4;
    EditText editText5;
    EditText editText6;
    EditText editText7;
    EditText editText8;

    TextView textViewSuma;
    TextView textViewResta;
    TextView textViewMult;
    TextView textViewDiv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        pantalla1=this.findViewById(R.id.layout1);
        pantalla2=this.findViewById(R.id.layout2);
        pantalla3=this.findViewById(R.id.layout3);
        pantalla4=this.findViewById(R.id.layout4);

        boton1=this.findViewById(R.id.button);
        boton2=this.findViewById(R.id.button2);
        boton3=this.findViewById(R.id.button3);
        boton4=this.findViewById(R.id.button4);
        botonSuma=this.findViewById(R.id.button5);
        botonResta=this.findViewById(R.id.button6);
        botonMult=this.findViewById(R.id.button7);
        botonDiv=this.findViewById(R.id.button8);

        editText1=this.findViewById(R.id.editText);
        editText2=this.findViewById(R.id.editText2);
        editText3=this.findViewById(R.id.editText3);
        editText4=this.findViewById(R.id.editText4);
        editText5=this.findViewById(R.id.editText5);
        editText6=this.findViewById(R.id.editText6);
        editText7=this.findViewById(R.id.editText7);
        editText8=this.findViewById(R.id.editText8);

        textViewSuma=this.findViewById(R.id.textView3);
        textViewResta=this.findViewById(R.id.textView6);
        textViewMult=this.findViewById(R.id.textView9);
        textViewDiv=this.findViewById(R.id.textView13);

        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pantalla1.setVisibility(View.VISIBLE);
                pantalla2.setVisibility(View.GONE);
                pantalla3.setVisibility(View.GONE);
                pantalla4.setVisibility(View.GONE);
            }
        });

        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pantalla2.setVisibility(View.VISIBLE);
                pantalla1.setVisibility(View.GONE);
                pantalla3.setVisibility(View.GONE);
                pantalla4.setVisibility(View.GONE);
            }
        });

        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pantalla3.setVisibility(View.VISIBLE);
                pantalla1.setVisibility(View.GONE);
                pantalla2.setVisibility(View.GONE);
                pantalla4.setVisibility(View.GONE);
            }
        });

        boton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pantalla4.setVisibility(View.VISIBLE);
                pantalla1.setVisibility(View.GONE);
                pantalla2.setVisibility(View.GONE);
                pantalla3.setVisibility(View.GONE);
            }
        });

        botonSuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double operacion = Double.valueOf(editText1.getText().toString()) + Double.valueOf(editText2.getText().toString());
                textViewSuma.setText(operacion.toString());
            }
        });

        botonResta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double operacion = Double.valueOf(editText3.getText().toString()) - Double.valueOf(editText4.getText().toString());
                textViewSuma.setText(operacion.toString());
            }
        });

        botonDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(editText6.getText().toString().equals("0")){
                    textViewDiv.setText("ERROR");
                }else{
                    Double operacion = Double.valueOf(editText5.getText().toString()) / Double.valueOf(editText6.getText().toString());
                    textViewSuma.setText(operacion.toString());
                }

            }
        });

        botonMult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double operacion= Double.valueOf(editText7.getText().toString()) * Double.valueOf(editText8.getText().toString());
                textViewMult.setText(operacion.toString());
            }
        });
    }
}
